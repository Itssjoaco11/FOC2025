const { response, request } = require('express')

class UserController{
    constructor(){
        console.log("Instancia del UserController")
    }
    getAll(req = request, res = response){

        return res.status(200).json({
            msj: "Get All",
        })

    }
    getOne(req = request, res = response){
        const { id } = req.params; //extraemos el id
        return res.status(200).json({
            msj: "Get One",
            id
        })

    }
    created(req = request, res = response){
        const { name, email, password, role_id } = req.body; //extraemos el body
        return res.status(200).json({
            msj: "Created",
            role:{
                name, email, password, role_id
            }
        })

    }
    updated(req = request, res = response){
        const { id } = req.params; //extraemos el id
        const { name, email, password, role_id } = req.body; //extraemos el body
        return res.status(200).json({
            msj: "Udated",
            id,
            role:{
                name, email, password, role_id, status:true
            }
        })

    }
    deleted(req = request, res = response){
        const { id } = req.params; //extraemos el id
        return res.status(200).json({
            msj: "Deleted",
            id
        })

    }
}

module.exports = {
    UserController
}