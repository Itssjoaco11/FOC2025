const { response, request } = require('express');
const { RoleServices } = require('../services/role.service');

class RoleController {

    constructor() {
        console.log("Instanciamos el Role Controller")
        this.role_services = new RoleServices();
    }

    getAll = (req = request, res = response) => {
        const roles = this.role_services.getAll()
        if (this.role_services.getCount() <= 0) {
            return res.status(404).json({
                msj: "Registros No Encontrados"
            })
        } else {
            return res.status(200).json({
                msj: "Registros Encontrados",
                roles
            })
        }

    }

    getOne = (req = request, res = response) => {
        const { id } = req.params;
        const role = this.role_services.getOne(Number(id))
        if(!role){
            return res.status(400).json({
            msj: "Registro no encontrado", id
        });
        }else{
            return res.status(200).json({
                msj:"Registro encontrado", role
            })
        }
    }

    created = (req = request, res = response) => {
        const { name } = req.body;
        const data = {
            name
        }
        const role = this.role_services.created(data)
        return res.status(201).json({
            msj: "Registrado exitosamente"
        })
    }

    uptaded = (req = request, res = response) => {
        const { id } = req.params;
        const { name } = req.body;
        const data = {
            name
        }
        const role = this.role_services.updated(Number(id), data)
        return res.status(200).json({
            msj: "Actualizado Correctamente"
        })
    }

    deleted = (req = request, res = response) => {
        const { id } = req.params;
        const role = this.role_services.deleted(Number(id))
        return res.status(200).json({
            msj: "Eliminado Correctamente"
        })
    }
}

module.exports = {
    RoleController
}