
let role = {
    id:1,
    name:"Administrador",
    status:true
}

let roles = [role]
    module.exports = { roles }