const { roles } = require("../models/role.models");

class RoleServices {

    constructor() {
        this.roles = roles;
    }

    getAll = () => {
        return this.roles;
    }

    getOne = (id) => {
        const role = this.roles.find((x) => {
            if (x.id === id) {
                return true
            }
        });
        return this.roles;
    }

    getName = (name) => {
        const role = this.roles.find((x) =>{
            if (x.name === name) {
                return true
            }
        });
        return role;
    }

    getIndice = (id) => {
        const role = this.roles.findIndex((x) => {
            if (x.id === id) {
                return true
            }
        });
        return role;
    }

    updated = (id, role) =>{
        const data={
            id,
            name:role.name,
            status:true
        }
        let i=this.getIndice(id)
        this.roles[i]=data;
        return role;
    }

    deleted = (id) =>{
        let i=this.getIndice(id)
        const role = this.roles.splice(i,1)
        return role;
    }

    created = (role) => {
        const data = {
            id: this.roles.length + 1,
            name: role.name,
            status: true
        }
        this.roles.push(data)
        let role_new = this.getName(data.name)
        return role_new;
    }

    getCount = () => {
        return this.roles.length;
    }
}

module.exports = {
    RoleServices
}