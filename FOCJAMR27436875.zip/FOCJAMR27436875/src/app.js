require('dotenv').config()
const { Server } = require("./server/server.server")

console.log("Hola mundo")
//Instancia de clase
const server = new Server()
server.listen()