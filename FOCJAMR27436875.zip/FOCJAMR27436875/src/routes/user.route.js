const { Router } = require("express");
const { UserController } = require('../controllers/user.controller');


const router = Router();
const user_controller = new UserController();
const user_validator = new UserValidator();
router.get('/',user_controller.getAll);
module.exports = router;
router.get('/:id', user_controller.getOne);
module.exports = router;
router.put('/:id',user_controller.updated);
module.exports = router;
router.delete('/:id',user_controller.deleted);
module.exports = router;