const { Router } = require("express");
const { RoleController } = require("../controllers/role.controller");

const router = new Router()
const role_controller = new RoleController()
router.get("/",role_controller.getAll)
router.get("/:id",role_controller.getOne)
router.get("/",role_controller.created)
router.get("/:id",role_controller.uptaded)
router.get("/:id",role_controller.deleted)
module.exports = router